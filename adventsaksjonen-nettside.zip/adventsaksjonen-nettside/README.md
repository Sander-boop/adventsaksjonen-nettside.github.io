# Nettside for Adventsaksjonen

Dette er grovkoden til nettsiden din – fire HTML-sider, ett stilark (CSS)
og ett lite script. Du trenger ikke installere noe for å begynne å
redigere. Se den fulle forklaringen i chatten for veien fra «åpne filene»
til «siden er på nett», men her er en kjapp oppsummering:

## Filer

- `index.html` – Hjem (forsiden, med "tenn lys"-illustrasjon og giverinfo)
- `prosjektet.html` – Om prosjektet
- `organisasjonen.html` – Om organisasjonen
- `om-oss.html` – Om oss
- `styles.css` – alle farger, skrifttyper og layout
- `script.js` – kun for mobilmenyen (hamburger-knappen)
- `images/` – legg bilder her, og bytt ut placeholder-bokser i HTML-en

## Ting du MÅ bytte ut

Søk (Ctrl+F / Cmd+F) etter hakeparenteser `[...]` i alle HTML-filene.
Disse markerer tekst du skal fylle inn selv, blant annet:

- `[Navn]` / `[navn på menighet/gruppe]` – navnet på gruppen din
- `[år]` – årstall for aksjonen
- `[navn på organisasjon]` – organisasjonen pengene går til
- Vipps-nummer og kontonummer i giverboksen på forsiden
- E-post, telefon og adresse i footeren
- Tekstene under "Om prosjektet", "Om organisasjonen" og "Om oss"

## Endre farger eller skrift

Åpne `styles.css` og se helt på toppen, under `:root`. Der ligger alle
fargene som navngitte variabler (f.eks. `--gold: #E3A857;`). Endrer du en
verdi her, endres den automatisk overalt på siden.

## Publisere siden

Den enkleste måten er Netlify Drop: gå til
https://app.netlify.com/drop og dra hele denne mappen inn i nettleseren.
Da får du en lenke siden er live på i løpet av sekunder. Detaljert
forklaring (inkludert eget domene) finner du i chat-svaret.
